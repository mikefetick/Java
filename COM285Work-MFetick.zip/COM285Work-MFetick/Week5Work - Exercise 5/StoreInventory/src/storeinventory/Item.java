/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 * Exercise 5 - Read a file to an ArrayList and Sort it(2 points)
 *   Step 2. Create constructor for:
 *           Item.Item(String ItemID, String ItemName, double SellingPrice)
 *   (3 Steps)
 */
package storeinventory;

/**
 * 2)Add the java class Item to store the information about the items
 * @author Michael Fetick, 84270
 */
public class Item implements Comparable<Item> { // 2)Class declaration
//public class Item { // 2)Class declaration

    // State of an Item. 3)Declare instance variables
    private String strItemID;       //The item ID
    private String strItemName;     //The item name
    private int intPiecesInStore;   //The number of pieces in the store
    private double dblManufPrice;   //The manufacturer's price
    private double dblSellingPrice; //The selling price

    // 4)Use NetBeans to generate Constructors
    public Item() { 
        this.strItemID = "";
        this.strItemName = "";
        this.intPiecesInStore = 0;
        this.dblManufPrice = 0.0;
        this.dblSellingPrice = 0.0;
    }

    //Constructor for Exercise 5, Product.csv file for ArrayList element
    public Item(String ItemID, 
                String ItemName, 
                double SellingPrice) {
        this.strItemID = ItemID;
        this.strItemName = ItemName;
        this.dblSellingPrice = SellingPrice;
    }

    public Item(String strItemID, 
                String strItemName, 
                int intPiecesInStore, 
                double dblManufPrice, 
                double dblSellingPrice) {
        this.strItemID = strItemID;
        this.strItemName = strItemName;
        this.intPiecesInStore = intPiecesInStore;
        this.dblManufPrice = dblManufPrice;
        this.dblSellingPrice = dblSellingPrice;
    }

    // Behavior of an Item. 5)Use NetBeans to generate getters and setters
    public String getStrItemID() {  
        return strItemID;
    }

    public void setStrItemID(String strItemID) {
        this.strItemID = strItemID;
    }

    public String getStrItemName() {
        return strItemName;
    }

    public void setStrItemName(String strItemName) {
        this.strItemName = strItemName;
    }

    public int getIntPiecesInStore() {
        return intPiecesInStore;
    }

    public void setIntPiecesInStore(int intPiecesInStore) {
        this.intPiecesInStore = intPiecesInStore;
    }

    public double getDblManufPrice() {
        return dblManufPrice;
    }

    public void setDblManufPrice(double dblManufPrice) {
        this.dblManufPrice = dblManufPrice;
    }

    public double getDblSellingPrice() {
        return dblSellingPrice;
    }

    public void setDblSellingPrice(double dblSellingPrice) {
        this.dblSellingPrice = dblSellingPrice;
    }
                        
    // 6) Override the toString() method
    @Override
    public String toString() {
        return super.toString(); 
    }

    @Override
    public int compareTo(Item e) {
//        String strThisItem = this.strItemName;
//        String strE = e.getStrItemName();
        String strThisItem = this.strItemID;
        String strE = e.getStrItemID();
        int itemComparison = strThisItem.compareTo(strE);
        return itemComparison;
    }
}
