/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Exercise 5 - Read a file to an ArrayList and Sort it(2 points)
 *   (3 Steps)
 *   Step 1. Create DataFileOperations.readProductFile()
 */
package storeinventory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.util.*;
import static storeinventory.Inventory.checkToQuit;

/**
 * 9)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy/Rename files: SinglyLinkedList, Operations, and Node
 *   b)This class uses LinkedListOps to readCustomerFile
 *   c)Correct the package name
 *   d)Correct the main method to be method readCustomerFile
 * @author Michael Fetick, 84270
 */
public class DataFileOperations extends LinkedListOps {
    /**
     * @param args the command line arguments
     */

    public static int readCustomerFile() {
        // While scanner hasNext, set string to next node
        LinkedListOps opns = new LinkedListOps();    
        FileReader testFile = null;
        try {
            testFile = new FileReader("customer2.csv");
        } catch (FileNotFoundException ex) {
            System.out.println("Something bad happened");
        }
        Scanner scanner = new Scanner(testFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter(",|\\n");  // Comma Separated Value csv file
        while (scanner.hasNext()) { // while has next recond - not end of file
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            double creditLimit = scanner.nextDouble();
            Customer newNode = new Customer(idNumber, name, creditLimit);
            newNode.setNext(null);  //Good practice to avoid a stray pointer
            opns.insertInOrder(newNode);
            scanner.next();
        }
        opns.list();

        Scanner input = new Scanner(System.in);
        int customerID = 0;
        while (customerID == 0) {
            System.out.println("\nPlease enter the Customer's idNumber "
                    + "(or 999 to quit):");
            String s = input.next();
            checkToQuit(s);
            customerID = Integer.parseInt(s); 
        }
        System.out.println();
        try {
            if (testFile != null){
                testFile.close();
            }
        } catch (IOException npe) {
            System.out.println("Something bad happened");
        }
        return customerID;
    }

/*
    public static ArrayList sortAlProducts() throws NoSuchElementException {
        
    }
*/
        public static ArrayList readProductFile() throws NoSuchElementException {
        
        FileReader productDataFile = null;
        try { 
            productDataFile = new FileReader("Product.csv");
        } catch (FileNotFoundException fnfe) {
            System.err.println("Product datafile:  " + fnfe.getMessage());
            System.exit(1);
        }
        Scanner scanner = new Scanner(productDataFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter("[,\n]");  // Comma Separated Value csv file
	 ArrayList<Item> alProducts = new ArrayList();
        int i = 0;
        while (scanner.hasNext()) { // while has next recond
            // Changed from int to String
            String productId = scanner.next();
            String productName = scanner.next();
            String productPrice = scanner.next();
            double dblProductPrice = Double.parseDouble(productPrice); 
            Item thisItem1 = new Item(productId,
                                     productName,
                                     dblProductPrice);
            alProducts.add(thisItem1);
        }
        try {
            if (productDataFile != null){
                productDataFile.close();
            }
        } catch (IOException ioe) {
            System.err.println("Product datafile:  " + ioe.getMessage());
            System.exit(1);
        }
        return alProducts;
    }
    
}

