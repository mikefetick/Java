/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 *
 * @author admin
 */
public interface AdjustmentConstants {

    final static double CASH_DISCOUNT = .98; //2% CASH DISCOUNT
    final static String CASH_DISCOUNT_STR = "Minus 2% cash discount";
    final static double CREDIT_SURCHARGE = 1.02; //2% CREDIT SURCHARGE
    final static String CREDIT_SURCHARGE_STR = "Add 2% credit surcharge";
    final static double SHIPPING_HANDLING_FEE = 4.00; //2% CREDIT SURCHARGE
    
}
