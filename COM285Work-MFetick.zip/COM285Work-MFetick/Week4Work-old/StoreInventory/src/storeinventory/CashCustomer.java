/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 9)This subclass is extended from superclass: Customer
 * @author Michael Fetick, 84270
 */
public class CashCustomer extends Customer {
    
    private String customerType;
        
    public CashCustomer(int customerId,
                        String customerName,
                        double creditLimit,
                        Node p) {
//                        String creditType) {

//        super(customerId, customerName, creditLimit, p);
        super();
        String creditType = p.getCreditType();
        setCreditType(creditType);
    }
    
    public String getCreditType() {
        String creditType = "CashCustomer";
        return creditType;
    }

    private void setCreditType(String creditType) {
        this.customerType = creditType;
    }
}
