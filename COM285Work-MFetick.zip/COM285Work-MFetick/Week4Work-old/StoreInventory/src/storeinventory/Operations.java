/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.util.*;
import static storeinventory.Inventory.checkToQuit;

/**
 * 9)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy all files: SinglyLinkedList.java, Operations.java, and Node.java
 *   b)This class performs Operations to readCustomerFile
 *   c)Change the package from singlylinkedlist to storeinventory
 *   d)Rename the main method to public static void readCustomerFile
 * @author Michael Fetick, 84270
 */
public class Operations extends Customer {
    /**
     * @param args the command line arguments
     */

    public static int readCustomerFile() {
        // While scanner hasNext, set string to next node
        Operations opns = new Operations();    
        FileReader testFile = null;
        try {
            testFile = new FileReader("customer2.csv");
        } catch (FileNotFoundException ex) {
            System.out.println("Something bad happened");
        }
        Scanner scanner = new Scanner(testFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter(",|\\n");  // Comma Separated Value csv file
        while (scanner.hasNext()) { // while has next recond - not end of file
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            double creditLimit = scanner.nextDouble();
            Node newNode = new Node(idNumber, name, creditLimit);
            newNode.setNext(null);  //Good practice to avoid a stray pointer
            opns.insertInOrder(newNode);
            scanner.next();
        }
        opns.list();

        Scanner input = new Scanner(System.in);
        int customerID = 0;
        while (customerID == 0) {
            System.out.println("\nPlease enter the Customer's idNumber "
                    + "(or 999 to quit):");
            String s = input.next();
            checkToQuit(s);
            customerID = Integer.parseInt(s); 
        }
        System.out.println();
        try {
            if (testFile != null){
                testFile.close();
            }
        } catch (IOException npe) {
            System.out.println("Something bad happened");
        }
        return customerID;
    }
}

