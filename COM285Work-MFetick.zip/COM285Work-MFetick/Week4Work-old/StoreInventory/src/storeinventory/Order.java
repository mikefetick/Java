/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 9)Add the java class Order to store information about the customer's order
 * @author Michael Fetick, 84270
 */
import java.util.*;
import java.text.DecimalFormat;

public class Order extends Operations implements AdjustmentConstants {

    private Node next;
    private int idNumber;
    private String name;
    private static String totalStr;
//    private static double creditLimit;
    private static double total = 0;
    private static Scanner input = new Scanner(System.in);
//    private static double cashDiscount = 0;
//    private static String cashDiscountStr = "";

    //Class variable formNumber for all the methods
    static DecimalFormat formNumber = new DecimalFormat("$#,###,###.00");

    public static void payByCash(String cashDiscountStr){
        System.out.println("  "+ CASH_DISCOUNT_STR +": - "+ cashDiscountStr);
        System.out.printf("  Your CASH is accepted, \n");
    }
    public static void payByCredit(String creditSurchargeStr){
        System.out.println("  " + CREDIT_SURCHARGE_STR + ":  + " 
                                + creditSurchargeStr);
        System.out.printf("  Your CREDIT will be charged, \n");
    }
    public static void orderProcessing (Node customer, 
                                        Item item, 
                                        int qtyOrdered, 
                                        int qoh) {
        int newqoh = qoh - qtyOrdered;
        String strItemName = "";
        String itemOrderedStr = String.format("%-12s", strItemName);
        double sellingPrice = item.getDblSellingPrice();
        String sellingPriceStr = String.format("%8s",
                                           formNumber.format(sellingPrice));
        double subTotal = qtyOrdered * sellingPrice;
        String subTotalStr = String.format("%8s",
                        formNumber.format(subTotal));
        String shippingFeeStr = String.format("%5s",
                        formNumber.format(SHIPPING_HANDLING_FEE));
        String plusShipHandStr = String.format("%8s",
                        formNumber.format(subTotal+SHIPPING_HANDLING_FEE));
        double cashDiscount = subTotal * (1-CASH_DISCOUNT);
        String cashDiscountStr = String.format("%8s",
                        formNumber.format(cashDiscount));
    
        //Prompt for orderType, in store or online
        int orderType = 0;
        while(orderType == 0){
            System.out.println("\n"
                             + "Store Order - - - - - - - - - - - - - - ");
            strItemName = item.getStrItemName();
            System.out.printf(" (%d)%s X %s = %s\n", 
                              qtyOrdered, 
                              strItemName, 
                              sellingPriceStr, 
                              subTotalStr);
            System.out.println("Enter: 1 for in-store order "
                    + "(save shipping & handling charge)");
            System.out.println("       2 for online-order "
                    + "(add " + shippingFeeStr
                    + " shipping & handling charge)");
            System.out.println();
            String s = input.next();
            if(s.equals("1")){
                orderType = 1;
            }else if(s.equals("2")){
                orderType = 2;
                subTotal = subTotal + 4;
                System.out.println(
                       "add " + shippingFeeStr + " S&H charge for subtotal: " 
                     + plusShipHandStr);
            }
        }
        //Call method to findCustomerId(n) and getCreditLimit
        int creditType = 0;
        double creditLimit = customer.getCreditLimit();
        String creditLimitStr = String.format("%8s",
                                formNumber.format(creditLimit));
        double cashTotal = subTotal * CASH_DISCOUNT;
        String cashTotalStr = String.format("%8s",
                              formNumber.format(cashTotal));
        double creditTotal = subTotal * CREDIT_SURCHARGE;
        String creditTotalStr = String.format("%8s",
                                formNumber.format(creditTotal));
        double creditSurcharge = subTotal * (CREDIT_SURCHARGE - 1);
        String creditSurchargeStr = String.format("%8s",
                                    formNumber.format(creditSurcharge));
        System.out.println("\nCustomer Selected - - - - - - - - - - -"); 
        System.out.println("  ID  Name                 Credit Limit"); 
        System.out.printf("%4d  %-20s %7.2f\n", 
                          customer.getIdNumber(), 
                          customer.getName(),
                          customer.getCreditLimit());
        System.out.println("\n"
                         + "Payment type  - - - - - - - - - - - - - ");
        if(creditLimit == 0){
            creditType = -2;
            System.out.println(
                           "No credit on account, CASH only payment.");
            item.setIntPiecesInStore(newqoh);
            System.out.println("\nYour order is accepted.\n"); 
            System.out.printf(" (%d)%s X %s = %s\n", 
                              qtyOrdered, 
                              itemOrderedStr, 
                              sellingPriceStr, 
                              subTotalStr);
            if(orderType == 2){
                System.out.println("  Add shipping & handling:       "
                                 + shippingFeeStr);
            }
            payByCash(cashDiscountStr);
            total = cashTotal;
        }else{
            creditType = 2;
            if(creditTotal > creditLimit) {
                System.out.println(
                        "Insufficient credit for purchase: " + creditTotalStr); 
                System.out.println(
                        "CASH only payment: " + cashTotalStr);
                item.setIntPiecesInStore(newqoh);
                System.out.println("\nYour order is accepted.\n"); 
                System.out.printf(" (%d)%s X %s = %s\n", 
                                  qtyOrdered, 
                                  itemOrderedStr, 
                                  sellingPriceStr, 
                                  subTotalStr);
                if(orderType == 2){
                    System.out.println("  Add shipping & handling:       "
                                     + shippingFeeStr);
                }
                payByCash(cashDiscountStr);
                total = cashTotal;
            }else{
                //Prompt for payType, cash or credit
                int payType = 0;
                strItemName = item.getStrItemName();
                while(payType == 0){
                    System.out.print("Enter: 1 to pay by CASH ");
                    System.out.println("(" + CASH_DISCOUNT_STR + ":    -"
                          + cashDiscountStr + ")");
                    System.out.print("       2 to pay by CREDIT ");
                    System.out.println("(" + CREDIT_SURCHARGE_STR + ": +"
                          + creditSurchargeStr + ")");
                    String s = input.next();
                    if(s.equals("1")){
                        item.setIntPiecesInStore(newqoh);
                        payType = 1;
                        System.out.println("\nYour order is accepted.\n"); 
                        System.out.printf(" (%d)%s X %s = %s\n", 
                                          qtyOrdered, 
                                          itemOrderedStr, 
                                          sellingPriceStr, 
                                          subTotalStr);
                        if(orderType == 2){
                            System.out.println(
                                    "  Add shipping & handling:       "
                                  + shippingFeeStr);
                        }
                        payByCash(cashDiscountStr);
                        total = cashTotal;
                    }else if(s.equals("2")){
                        item.setIntPiecesInStore(newqoh);
                        payType = 2;
                        System.out.println("\nYour order is accepted,"
                                + " confirmation number: 201306170101\n"); 
                        System.out.printf(" (%d)%s X %s = %s\n", 
                                          qtyOrdered, 
                                          strItemName, 
                                          sellingPriceStr, 
                                          subTotalStr);
                        if(orderType == 2){
                            System.out.println(
                                    "  Add shipping & handling:       "
                                  + shippingFeeStr);
                        }
                        payByCredit(creditSurchargeStr);
                        total = creditTotal;
                        }
                    }//end else if
                totalStr = String.format("%8s",formNumber.format(total));
                System.out.printf("                       "
                                + "Total: %s", totalStr);
                System.out.printf("\n  Thank you.");
                System.out.print("\n\nPress 1 to continue...");
                String s = input.next();
                }//end While:payType = 0
            }//end else: Prompt for payType, cash or credit
        }//end else: Call method to getCreditLimit
    }