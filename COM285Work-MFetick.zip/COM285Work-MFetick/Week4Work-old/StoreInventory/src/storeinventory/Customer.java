/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 8)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy all files: SinglyLinkedList.java, Operations.java, and Node.java
 *   b)Rename this file from SinglyLinkedList.java to Customer.java
 *   c)Change their package from singlylinkedlist to storeinventory
 *   d)Rename the main method to public static void readCustomerFile
 * 9)This superclass is extended to subclasses: CashCustomer, CreditCustomer
 * @author Michael Fetick, 84270
 */
public class Customer {

    protected static int    thisCustomerId   = 0;
    protected static String thisCustomerName = "";
    protected static double thisCreditLimit  = 0;
    protected static String thisCustomerType = "";
    protected static Node p = null;

    public static Node head = null;
    
//    public Customer(int customerId, 
//                    String customerName, 
//                    double creditLimit) {
    public Customer() {
        p = head;
        while(p != null){
            //New: make instance variables to pass to subclasses
            thisCustomerId = p.getIdNumber();
            thisCustomerName = p.getName();
            thisCreditLimit = p.getCreditLimit();
            //Pass to subclass CashCustomer to build a list
            if (thisCreditLimit == 0) {
                Customer aCashCustomer = new CashCustomer(thisCustomerId,
                                                          thisCustomerName,
                                                          thisCreditLimit,
                                                          p);
            }
            System.out.printf("%4d  %-20s %7.2f %-20s\n", 
                    thisCustomerId, 
                    thisCustomerName,
                    thisCreditLimit,
                    thisCustomerType);
//            System.out.printf("%4d  %-20s %7.2f\n", 
//                    p.getIdNumber(), 
//                    p.getName(),
//                    p.getCreditLimit());
            p = p.getNext(); // advance through list
        }
    }

    /**
     *
     * @param customerId
     * @return
     */
//    public static int findCustomerId(int customerId){
    public static Node findCustomerId(int customerId){
        Node p;
        p = head;
        Node thisNode = p;
        while(p != null){
            if (p.getIdNumber() == customerId) {
                thisNode = p;
                thisCustomerId = customerId;
                thisCustomerName = p.getName();
                thisCreditLimit = p.getCreditLimit();
            }
            p = p.getNext(); // advance through list
        }
        return thisNode;
    }

    public void insert(Node newNode){
        if(head == null){
            head = newNode;
            return;
        }
        newNode.setNext(head);
        head = newNode;     
    }   

    public void insertInOrder(Node newNode){    
        Node p, q;
        // case 1: the list is empty
        if(head == null){
            head = newNode;
            return;
        }
        // case 2: the node at head is >= to the new node so insert new node in front
        if(head.getIdNumber() > newNode.getIdNumber()){
            newNode.setNext(head); // attach the list to the new node
            head = newNode;      // point head at the new node
            return;
        }
        // case 3: the node at head is less than the new node
        p = head;
        q = head;
        while(p.getIdNumber() < newNode.getIdNumber() ){
           q = p;               // q follows p
           p = p.getNext();     // advance p in list to next node
           if(p == null){       // if end of list break to append newNode
               break;
           }
        }
        q.setNext(newNode);     // insert the newNode
        newNode.setNext(p);     // newNode point to the rest of the list or null
    }
    public static void list(){
        System.out.println("Customer Database - - - - - - - - - - -"); 
        System.out.println("  ID  Name                 Credit Limit"); 
        Customer(thisCustomerId,thisCustomerName,thisCreditLimit,p);
    }
}