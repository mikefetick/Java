/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

import java.util.*;
import static storeinventory.Inventory.itemReport;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */

public class StoreInventory extends Inventory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // While loop, menu display/input, call methods of arraylist

        ArrayList<Item> alMain = initializeItem();
        Scanner input = new Scanner(System.in);
        int n = 0;
        String s;
        
//        while(true){ // while exit has not been selected
        while(n!=4){ // while exit has not been selected
            displayMenu();
            s = input.next(); // Accept the keyboard entry
            System.out.println();    // Move down to a fresh line
            n = Integer.parseInt(s); 

            //Welcome to the Java Hardware Store
            switch(n){
                //1. Check whether an item is in the store
                case 1: itemCheckDialogue(alMain); 
                          continue;
                //2. Sell an item
                case 2: sellAnItem(alMain);
                          continue;
                //3. Print the report
                case 3: itemReport(alMain); 
                          continue;
                //4. Exit
                case 4: 
                    System.out.println(
                               "\nThank you for using this program.\n");
                    System.exit(0);
                default: 
                    System.out.printf(
                               "\nPlease select 1, 2, 3, ot 4.\n\n");
            } // switch        
        } // while
    } // main
} // StoreInventory