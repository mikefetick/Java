/* COM285, Michael Fetick, 84270
 * Exercise Checkup
 */
package testcheckup;

public class Checkup {

    int patientNumber;
    double systolic;
    double diastolic;
    double ldl;
    double hdl;

    public Checkup() {
        this.patientNumber = 0;
        this.systolic = 0;
        this.diastolic = 0;
        this.ldl = 0;
        this.hdl = 0;
    }
   
    public Checkup(int patientNumber, double systolic, 
            double diastolic, double ldl, double hdl) {

        this.patientNumber = patientNumber;
        this.systolic = systolic;
        this.diastolic = diastolic;
        this.ldl = ldl;
        this.hdl = hdl;
    }

    public int getPatientNumber() {
        return patientNumber;
    }

    public void setPatientNumber(int patientNumber) {
        this.patientNumber = patientNumber;
    }

    public double getSystolic() {
        return systolic;
    }

    public void setSystolic(double systolic) {
        this.systolic = systolic;
    }

    public double getDiastolic() {
        return diastolic;
    }

    public void setDiastolic(double diastolic) {
        this.diastolic = diastolic;
    }

    public double getLdl() {
        return ldl;
    }

    public void setLdl(double ldl) {
        this.ldl = ldl;
    }

    public double getHdl() {
        return hdl;
    }

    public void setHdl(double hdl) {
        this.hdl = hdl;
    }
    public double computeRatio(){
        return ldl / hdl;
    }
    
    public String explainRatio(double ratio){
        if(ratio <= 3.5){
            return "Cholesterol ratio is optimum (<= 3.5).";
        }
        else{
            return "Cholesterol ratio is not optimum (> 3.5).";
        }
    }
}
