/* COM285, Michael Fetick, 84270
 * Exercise Checkup
 */
package testcheckup;

public class TestCheckup {

    public static void main(String[] args) {
        // Create array of objects
        Checkup[] p = new Checkup[4];
        p[0] = new Checkup(1, 160.0, 100.0, 150.0, 40.0);
        p[1] = new Checkup(2, 135.0, 75.0, 200.0, 50.0);
        p[2] = new Checkup(3, 120.0, 70.0, 225.0, 75.0);
        p[3] = new Checkup(4, 150.0, 90.0, 180.0, 30.0);
        
        for(int i = 0; i < 4; i++){
            System.out.println("PatientNumber = "
                    + p[i].getPatientNumber());
            System.out.println("Blood Pressure = " 
                    + p[i].getSystolic()
                    + " / "
                    + p[i].getDiastolic());
            System.out.println("Cholesterol LDL, HDL = "
                    + p[i].getLdl()
                    + ", "
                    + p[i].getHdl());
            System.out.println("LDL/HDL = " 
                    + p[i].computeRatio());
            System.out.println("explain ratio is " 
                    + p[i].explainRatio(p[0].computeRatio()));
        }
    }
}
/*
run:
PatientNumber = 1
Blood Pressure = 160.0 / 100.0
Cholesterol LDL, HDL = 150.0, 40.0
LDL/HDL = 3.75
explain ratio is Cholesterol ratio is not optimum (> 3.5).
PatientNumber = 2
Blood Pressure = 135.0 / 75.0
Cholesterol LDL, HDL = 200.0, 50.0
LDL/HDL = 4.0
explain ratio is Cholesterol ratio is not optimum (> 3.5).
PatientNumber = 3
Blood Pressure = 120.0 / 70.0
Cholesterol LDL, HDL = 225.0, 75.0
LDL/HDL = 3.0
explain ratio is Cholesterol ratio is not optimum (> 3.5).
PatientNumber = 4
Blood Pressure = 150.0 / 90.0
Cholesterol LDL, HDL = 180.0, 30.0
LDL/HDL = 6.0
explain ratio is Cholesterol ratio is not optimum (> 3.5).
BUILD SUCCESSFUL (total time: 0 seconds)
*/