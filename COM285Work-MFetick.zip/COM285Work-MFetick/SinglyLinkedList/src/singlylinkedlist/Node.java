/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package singlylinkedlist;

/**
 * This class performs node methods
 * @author Michael Fetick, 84270
 */
public class Node {
    private Node next;
    private int idNumber;
    private String name;
    private double creditLimit;

    public Node(int idNumber, String name) {
        this.idNumber = idNumber;
        this.name = name;
    }    
    public Node(int idNumber, String name, double creditLimit) {
        this.idNumber = idNumber;
        this.name = name;
    }    
    public Node getNext() {
        return next;
    }
    public int getIdNumber() {
        return idNumber;
    }
    public String getName() {
        return name;
    }
    public double getCreditLimit() {
        return creditLimit;
    }
    public void setNext(Node next) {
        this.next = next;
    }
}