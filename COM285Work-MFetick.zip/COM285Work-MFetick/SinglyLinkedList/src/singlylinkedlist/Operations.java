/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 */
package singlylinkedlist;

/**
 * This class performs Operations
 * @author Michael Fetick, 84270
 */
public class Operations extends SinglyLinkedList{

    public static Node head = null;
    
    public void list(){
        Node p;
        p = head;
        while(p != null){
            System.out.printf("%4d  %-20s \n", p.getIdNumber(), p.getName());
//            System.out.printf("%4d  %-20s %6d\n", 
//                    p.getIdNumber(), 
//                    p.getName(),
//                    p.getCreditLimit());
            p = p.getNext(); // advance through list
        }
    }

    public void insert(Node newNode){
        if(head == null){
            head = newNode;
            return;
        }
        newNode.setNext(head);
        head = newNode;     
    }   

    public void insertInOrder(Node newNode){    
        Node p, q;
    // case 1: the list is empty
        if(head == null){
            head = newNode;
            return;
        }
    // case 2: the node at head is >= to the new node so insert new node in front
        if(head.getIdNumber() > newNode.getIdNumber()){
            newNode.setNext(head); // attach the list to the new node
            head = newNode;      // point head at the new node
            return;
        }
    // case 3: the node at head is less than the new node
        p = head;
        q = head;
        while(p.getIdNumber() < newNode.getIdNumber() ){
           q = p;               // q follows p
           p = p.getNext();     // advance p in list to next node
           if(p == null){       // if end of list break to append newNode
               break;
           }
        }
        q.setNext(newNode);     // insert the newNode
        newNode.setNext(p);     // newNode point to the rest of the list or null
        }
    }