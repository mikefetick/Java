/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * A subclass of superclass Customer
 * @author Michael Fetick, 84270
 */
public class CashCustomer extends Customer {
    
    private String paymentType;
    
    public CashCustomer(int idNumber, 
                        String name, 
                        double creditLimit, 
                        String cashPayment) {
        super(idNumber, 
              name, 
              creditLimit);
        this.setPaymentType(cashPayment);
    }
    
    private String getPaymentType() {
        return this.paymentType;
    }
    
    private void setPaymentType(String cashPayment) {
        this.paymentType = cashPayment;
    }

    public void subtractCashDiscount(double subTotal, double cashDiscount) {
//        subTotal = subTotal - cashDiscount;
//        return subTotal;
    }
}