/*
 * COM285, Michael Fetick, 84270
 * Project 4 - Spinner Threads (10 points)
 */
package SpinnerThreads;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

/*
 * @author Michael Fetick, 84270
 */
public class Main {

    private static JSlider slider;
    private static JLabel label;
    protected static double sliderSetting;

    public static void main(String[] args) {
        
        SwingSuspendResume vsr = new SwingSuspendResume();
        Thread t = new Thread(vsr);

        JFrame frame = new JFrame();
        frame.setContentPane(vsr);
        frame.setSize(320, 250);
        frame.setVisible(true);

	slider = new JSlider();
        int sliderValue = 50;
	slider.setValue(sliderValue);
	slider.addChangeListener(new MyChangeAction());
        String str = Integer.toString(sliderValue);
        label = new JLabel(str + "%");
        
        JPanel panel = new JPanel();
	panel.add(slider);
	panel.add(label);
	frame.add(panel, BorderLayout.CENTER);
        t.start();
        
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
    
        });
    }
    
    public static class MyChangeAction implements ChangeListener{
        
        protected int value;
        protected int sliderValue;
        
	public void stateChanged(ChangeEvent ce){
            value = slider.getValue();
            sliderSetting = (double) value;
            String str = Integer.toString(value);
            label.setText(str + "%");
            SwingSuspendResume.setDelay(value);           
	}
    }
}
