/* COM285, Michael Fetick, 84270
 * Exercise Bicycle
 */
package bicycle;

/**
 * 3)This class is for a Mountain Bike extended from Bicycle
 * @author Michael Fetick, 84270
 */
public class MountainBike extends Bicycle {
    private String suspension;

    public MountainBike(
               int startCadence,
               int startSpeed,
               int startGear,
               String suspensionType){
        super(startCadence,
              startSpeed,
              startGear);
        this.setSuspension(suspensionType);
    }

    public String getSuspension(){
      return this.suspension;
    }

    private void setSuspension(String suspensionType) {
        this.suspension = suspensionType;
    }

    @Override
     public void printDescription() {
        super.printDescription();
        System.out.println("The " + "MountainBike has " +
            getSuspension() + " suspension.");
    }
}
