/* COM285, Michael Fetick, 84270
 * Exercise Bicycle
 */
package bicycle;

/**
 * 5)This class is for a Tandem Bike extended from Bicycle
 * @author Michael Fetick, 84270
 */
public class TandemBike extends Bicycle {
    private int pedalStations;

    /**
     *
     * @param startCadence
     * @param startSpeed
     * @param startGear
     * @param pedalPositions
     */
    public TandemBike(
               int startCadence,
               int startSpeed,
               int startGear,
               int pedalPositions){
        super(startCadence,
              startSpeed,
              startGear);
        this.setPedalPositions(pedalPositions);
    }

    public int getPedalPositions(){
      return this.pedalStations;
    }

    private void setPedalPositions(int pedalPositions) {
        this.pedalStations = pedalPositions;
    }

    @Override
     public void printDescription() {
        super.printDescription();
        System.out.println("The " + "TandemBike has " +
            getPedalPositions() + " pedal stations.");
    }
}
