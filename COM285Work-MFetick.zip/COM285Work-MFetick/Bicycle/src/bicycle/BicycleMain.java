/* COM285, Michael Fetick, 84270
 * Exercise Bicycle
 */
package bicycle;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */
public class BicycleMain {
  public static void main(String[] args){
    Bicycle bike01, bike02, bike03, bike04;

    bike01 = new Bicycle(20, 10, 1);
    bike02 = new MountainBike(20, 10, 5, "Dual");
    bike03 = new RoadBike(40, 20, 8, 26);
    bike04 = new TandemBike(30, 15, 6, 2);

    bike01.printDescription();
    bike02.printDescription();
    bike03.printDescription();
    bike04.printDescription();
  }
}