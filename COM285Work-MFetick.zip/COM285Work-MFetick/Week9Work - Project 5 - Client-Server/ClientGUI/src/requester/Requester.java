package requester;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import storeinventory.Item;
import java.io.ObjectOutputStream;

public class Requester {
    
	Socket requestSocket;
	ObjectOutputStream out;
 	ObjectInputStream in;
 	String message;
        boolean streaming = false;
        String productId;
        String qtyOnHand;
        int intQtyOnHand;
        Item thisItem2;
        public ArrayList<Item> alInventory;
        
	void sendMessage(String msg)
	{
		try{
			out.writeObject(msg);
			out.flush();
			System.out.println("client>" + msg);
		}
		catch(IOException ioException){
			ioException.printStackTrace();
		}
	}
        
	Requester(){}
	void run()
	{
		try{
			//1. creating a socket to connect to the server
			requestSocket = new Socket("localhost", 2004);
			System.out.println("\nConnected to localhost in port 2004");
			//2. get Input and Output streams
			out = new ObjectOutputStream(requestSocket.getOutputStream());
			out.flush();
			in = new ObjectInputStream(requestSocket.getInputStream());
			//3: Communicating with the server
			try{
                            do{
                                message = (String)in.readObject();
                                System.out.println("server>" + message);
                                if (!message.equals(null)){
                                    if (message.equals("Connection successful")) {
                                        sendMessage("Send all");
                                    }else if (message.equals("Data start")) {
                                        streaming = true;
                                    }else if (message.equals("Data end")) {
                                        streaming = false;
                                    }else if (message.equals("bye")) {
                                        sendMessage(message);
                                    }
                                    if (streaming){
                                        //Next message IN is the itemID
                                        message = (String)in.readObject();
                                        System.out.println("server>" + message);
                                        productId = message;

                                        //Next message IN is the QOH
                                        message = (String)in.readObject();
                                        System.out.println("server>" + message);
                                        qtyOnHand = message;
                                        qtyOnHand = qtyOnHand.trim();
                                        int intQtyOnHand = (int) (Integer.parseInt(qtyOnHand)); 

                                        //Add the item to an ArrayList
                                        thisItem2 = new Item(productId, intQtyOnHand);
                                        try{
                                            boolean addItem = alInventory.add(thisItem2);
                                        } catch (NullPointerException npe){
                                        }
                                    }
                                }
                            }while(!message.equals("bye"));
			}catch(ClassNotFoundException classNot){
                            System.err.println(
                                "data received in unknown format");
                        } catch (EOFException eofe){
			}
		}
		catch(UnknownHostException unknownHost){
			System.err.println("You are trying to connect to an unknown host!");
		}
		catch(IOException ioException){
			ioException.printStackTrace();
		}
		finally{
			//4: Closing connection
			try{
				in.close();
				out.close();
				requestSocket.close();
			}
			catch(IOException ioException){
				ioException.printStackTrace();
			}
		}
	}
        public ArrayList<Item> getAlInventory(){
            return this.alInventory;
        }

        public static void main(String args[])
	{
		Requester client = new Requester();
		client.run();
	}
}
