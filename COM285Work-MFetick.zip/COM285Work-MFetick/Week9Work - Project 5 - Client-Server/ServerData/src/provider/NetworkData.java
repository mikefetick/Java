/* COM285, Michael Fetick, 84270
 * Project 5 - Server data: read data from file(s)
 */
package provider;

import java.io.ObjectOutputStream;
import java.util.NoSuchElementException;

/**
 * @author Michael Fetick, 84270
 */
public abstract class NetworkData extends DataFileOperations {

    /**
     *
     * @return
     * @throws NoSuchElementException
     */
    ObjectOutputStream out;
    
        public abstract boolean sentInventoryFile() throws NoSuchElementException;

    public boolean NetworkData() {
        return sentInventoryFile(out);
    }
}
