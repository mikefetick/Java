/* Coleman University - COM285, Michael Fetick, 84270 
 * Code examples from the textbook:
 * "Modern Software Development Using Java, 2nd Ed."
 *  by Paul T. Tymann and G. Michael Schneider
 */

package TextbookQueues;

/**  
 * A simple test program for the Queue used in the book.
 */

public class TestbookQueues {

    /**
     * Basic sanity check for Queue implementations.
     *
     * @param args types of lists to use
     */

    public static void main( String args[] ) {
        System.out.println( "Basic sanity check for Queue implementations:" );
        System.out.println( "* LinkedQueue<Integer>" );
        System.out.println( "---------------------" );
//        Queue<Integer> theList = new LinkedPriorityQueue<Integer>();
//        Queue<Integer> theList = new ArrayQueue<Integer>();
        Queue<Integer> theList = new LinkedQueue<Integer>();
        Queue<Integer> theList2 = new LinkedQueue<Integer>();
        
        //Should print True
        System.out.print( "Empty: " + theList.empty());
        System.out.println( "\t\t// To begin with, should print True." );
        
        theList.enqueue(1);
        
        //Should print False
        System.out.print( "Empty: " + theList.empty());
        System.out.print( "\t\t// False; after theList.enqueue(1)," );
        System.out.println( " it should not be empty." );
        
        System.out.print( theList.front() );
        System.out.println( "\t\t\t// The value of the front." );
        theList.dequeue();
        
        //Should print true
        System.out.print( "Empty: " + theList.empty());
        System.out.print( "\t\t// False; after theList.dequeue(1)," );
        System.out.println( " it should be empty." );
        
        for(int a = 0; a < 10; a++ ){
            theList.enqueue( a );
        }
        //Print 0-9 in reverse order
        while( !theList.empty() ){
            System.out.print( theList.front()+" ");
            theList2.enqueue(theList.front());
            theList.dequeue();
        }
        System.out.println( "\t// Print 0-9 in reverse order" );
        
        //Print 0-9 in order
        while( !theList2.empty() ){
            System.out.print( theList2.front()+" ");
            theList2.dequeue();
        }   
        System.out.println( "\t// Print 0-9 in order" );
    }
}