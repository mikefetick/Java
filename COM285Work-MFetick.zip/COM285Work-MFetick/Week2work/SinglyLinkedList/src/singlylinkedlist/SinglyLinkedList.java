/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 */
package singlylinkedlist;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */
public class SinglyLinkedList {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // While scanner hasNext, set string to next node
        Operations opns = new Operations();
        FileReader testFile = null;
            try {
                testFile = new FileReader("customer.csv");
            } catch (FileNotFoundException ex) {}

        Scanner scanner = new Scanner(testFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter(",|\\n");  // Comma Separated Value csv file
        while (scanner.hasNext()) {     // has next recond -- not end of file
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            double creditLimit = scanner.nextDouble();
            System.out.printf("idNumber = %d "
                            + "Name = %s "
                            + "creditLimit = %5.2f\n",
                              idNumber, name, creditLimit);
//            System.out.printf("idNumber = %d "
//                            + "Name = %s "
//                            + "creditLimit = ?\n",
//                              idNumber, name);
            Node newNode = new Node(idNumber, name);
//            Node newNode = new Node(idNumber, name, creditLimit);
            newNode.setNext(null);  //Good practice to avoid a stray pointer
            // opns.insert(newNode);
            opns.insertInOrder(newNode);
            scanner.next();
            }
          opns.list();
        }
    }

