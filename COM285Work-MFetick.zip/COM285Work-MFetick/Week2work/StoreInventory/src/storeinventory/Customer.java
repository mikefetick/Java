/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import static storeinventory.Inventory.checkToQuit;
import static storeinventory.Inventory.itemCheck;

/**
 * 8)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy all files: SinglyLinkedList.java, Operations.java, and Node.java
 *   b)Rename this file from SinglyLinkedList.java to Customer.java
 *   c)Change their package from singlylinkedlist to storeinventory
 *   d)Rename the main method to public static void readCustomerFile
 * @author Michael Fetick, 84270
 */
public class Customer extends Operations {
    /**
     * @param args the command line arguments
     */

    public static void readCustomerFile() {
        // While scanner hasNext, set string to next node
        Operations opns = new Operations();    
        FileReader testFile = null;
            try {
                testFile = new FileReader("customer2.csv");
            } catch (FileNotFoundException ex) {
                System.out.println("Something bad happened");
            }
        Scanner scanner = new Scanner(testFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter(",|\\n");  // Comma Separated Value csv file
        while (scanner.hasNext()) {     // has next recond -- not end of file
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            double creditLimit = scanner.nextDouble();
//            System.out.printf("idNumber = %d "
//                            + "Name = %s "
//                            + "creditLimit = %5.2f\n", 
//                              idNumber, name, creditLimit);
            Node newNode = new Node(idNumber, name, creditLimit);
            newNode.setNext(null);  //Good practice to avoid a stray pointer
            opns.insertInOrder(newNode);
            scanner.next();
        }
        opns.list();
        Scanner input = new Scanner(System.in);
        int customer = 0;
        while (customer == 0) {
            System.out.println("\nPlease enter the Customer's idNumber "
                    + "(or 999 to quit):");
            String s = input.next();
            checkToQuit(s);
            int n = Integer.parseInt(s); 
            customer = findCustomerId(n); // customer or null
            if(customer == 0){
                System.out.printf("The customerId %s was not found.\n", n);
            }
        }
    }
}