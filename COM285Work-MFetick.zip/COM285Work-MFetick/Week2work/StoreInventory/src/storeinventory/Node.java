/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 8)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy all files: SinglyLinkedList.java, Operations.java, and Node.java
 * This class performs node methods
 * @author Michael Fetick, 84270
 */
public class Node {
    private Node next;
    private int idNumber;
    private String name;
    private double creditLimit;

    public Node(int idNumber, String name) {
        this.idNumber = idNumber;
        this.name = name;
    }    
    public Node(int idNumber, String name, double creditLimit) {
        this.idNumber = idNumber;
        this.name = name;
        this.creditLimit = creditLimit;
    }    
    public Node getNext() {
        return next;
    }
    public int getIdNumber() {
        return idNumber;
    }
    public String getName() {
        return name;
    }
    public double getCreditLimit() {
        return creditLimit;
    }
    public void setNext(Node next) {
        this.next = next;
    }
}