/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 9)Add the java class Order to store information about the customer's order
 * @author Michael Fetick, 84270
 */
public class Order {
    
}
