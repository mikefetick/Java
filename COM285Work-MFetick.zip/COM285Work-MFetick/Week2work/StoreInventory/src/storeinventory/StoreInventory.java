/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

import java.util.*;
import static storeinventory.Inventory.itemReport;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */

public class StoreInventory extends Inventory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // While loop, menu display/input, call methods of arraylist

        ArrayList<Item> alMain = initializeItem();
        Scanner input = new Scanner(System.in);
        
        while(true){ // while exit has not been selected
            String s = null;
            displayMenu();
            s = input.next(); // Accept the keyboard entry
            System.out.println();    // Move down to a fresh line
            int n = Integer.parseInt(s); 

            //Welcome to the Java Hardware Store
            switch(n){
                //1. Check whether an item is in the store
                case 1: itemCheckDialogue(alMain); 
                          break;
                //2. Sell an item
                case 2: readCustomerFile();
                        itemReport(alMain);
                        sellAnItem(alMain);
                          break;
                //3. Print the report
                case 3: itemReport(alMain); 
                          break;
                //4. Exit
                case 4: 
                    System.out.println(
                               "\nThank you for using this program.\n");
                    System.exit(0);
                default: 
                    System.out.printf(
                               "\nPlease select 1, 2, 3, ot 4.\n\n");
            } // switch        
        } // while
    } // main
} // Inventory
/* OUTPUT
run


Welcome to the Java Hardware Store

1. Check whether an item is in the store
2. Sell an item
3. Print the report
4. Exit

1


Please enter the ItemId.
12
ItemId 12 Circular saw has an in-store inventory of 150.


Welcome to the Java Hardware Store

1. Check whether an item is in the store
2. Sell an item
3. Print the report
4. Exit

2


Please enter the ItemId.
301
ItemId 301 Table saw has an in-store inventory of 100.
How many do you want?
100

Your order for 100 Table saw [301] is accepted.
You will be charged $30000.00. Thank you.

Welcome to the Java Hardware Store

1. Check whether an item is in the store
2. Sell an item
3. Print the report
4. Exit

2


Please enter the ItemId.
301
ItemId 301 Table saw has an in-store inventory of 0.
How many do you want?
1
Sorry, there is insufficient inventory to fill your order.

Welcome to the Java Hardware Store

1. Check whether an item is in the store
2. Sell an item
3. Print the report
4. Exit

3

ItemId   Item Name        Pieces in Store  ManufPrice  SellingPrice
  12   Circular saw             150           45.00        125.00
 235   Cooking range             50          450.00        850.00
 301   Table saw                  0          125.00        300.00
 302   Stapler                  300           18.00         49.00
 303   Lawn tractor               5          300.00        650.00

  Total Inventory: $79200.00

  Total number of items in the store: 505



Welcome to the Java Hardware Store

1. Check whether an item is in the store
2. Sell an item
3. Print the report
4. Exit

4

BUILD SUCCESSFUL (total time: 2 minutes 20 seconds)

*/