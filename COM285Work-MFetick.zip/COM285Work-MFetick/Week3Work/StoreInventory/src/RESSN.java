/* COM285, Michael Fetick, 84270
 * Exercise - Java Regular Expressions
 * 06/19/2013
 */
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 84270
 */

public class RESSN {
    public static void main(String[] args) {
        List<String> input = new ArrayList<String>();
	input.add("123-45-6789");
	input.add("9876-5-4321");
	input.add("98765-4329");
	input.add("987-65-4321 (attack)");
	input.add("987-65-4321 ");
	input.add("192-83-7465");
	for (String ssn : input) {
            if (ssn.matches("^(\\d{3}-?\\d{2}-?\\d{4})$")) {
                System.out.println("Found good SSN: " + ssn);
        //Added the ? to make the dash (-) optional for both places
        //resulted an output that has the missing dash (-), missing.
        //seems to be a good snippet to catch, compare, and correct with
        //appending a dash (-) if it is missing.
            }
        }
    }
}
/*
run:
Found good SSN: 123-45-6789
Found good SSN: 98765-4329
Found good SSN: 192-83-7465
BUILD SUCCESSFUL (total time: 0 seconds)

*/