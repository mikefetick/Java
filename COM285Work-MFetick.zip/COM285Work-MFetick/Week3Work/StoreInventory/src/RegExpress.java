/* COM285, Michael Fetick, 84270
 * Exercise - Java Regular Expressions
 * 06/19/2013
 */
import java.util.regex.*;
import java.util.*;

/**
 *
 * @author 84270
 */
public class RegExpress {
    public static void main(String[] args) {

        //Enter three digits
//        System.out.print("Enter three digit numbers: ");
//        String myPattern = "^\\d{3}$";

        //Enter a phone number
//        System.out.print("Enter a phone number: ");
//        String myPattern = "^[2-9]\\d{2}-\\d{3}-\\d{4}$";
//        String myPattern = "^\\([2-9]\\d{2}\\)\\d{3}-\\d{4}$";

        //Enter a date
//        System.out.print("Enter a date: ");
//        String myPattern = "^(0[1-9]|1[012])" //Month
//                + "/"
//                + "(0[1-9]|[1-2][0-9]|3[01])" //Day
//                + "/"
//                + "(19|20)\\d\\d$";           //Year

        //Enter a social security number
//        System.out.print("Enter a social security number: ");
//        String myPattern = "^\\d{3}-\\d{2}-\\d{4}$";           //Year
        
        //Enter an email address
//        System.out.print("Enter an email address: ");
//        String myPattern = "^\\b[A-Z0-9._%+-]+"
//                + "@[A-Z0-9.-]+"
//                + "\\.[A-Z]{2,4}\\b$";           //Year
//        String myPattern = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+"
//        + "\.(?:[A-Z]{2}|com|org|net|edu|gov|mil|biz|info|"
//        + "mobi|name|aero|asia|jobs|museum)$";
        
        //Enter a phone number
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a phone number: ");
        String number = input.next();
        String myPattern = "^\\(\\d{3}\\)\\u0020\\d{3}-\\d{4}$";
        //Note: Java does not handle the unicode of whitespace \\u0020

        Pattern pattern = Pattern.compile(myPattern);
        Matcher match = pattern.matcher(number);
        if (match.find()) {
            System.out.println("Yes, it is in format.");
        } else {
            System.out.println("No, it is not in format");
        }
    }
}
/*
run:
Enter three digit numbers: 435
Yes, three digits.
BUILD SUCCESSFUL (total time: 3 seconds) 

run:
Enter three digit numbers: 4355
No, not three digits.
BUILD SUCCESSFUL (total time: 3 seconds) 

run:
Enter a date: 06/19/2013
Yes, it is in format.
BUILD SUCCESSFUL (total time: 4 seconds)

*/