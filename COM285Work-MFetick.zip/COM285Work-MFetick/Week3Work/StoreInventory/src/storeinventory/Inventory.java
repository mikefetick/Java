/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
*/
package storeinventory;

/**
 * 7)Add the java class Inventory to contain a vector of items
 * @author Michael Fetick, 84270
 */
import java.util.*;

public class Inventory extends Order {

    private Node next;

    public static ArrayList initializeItem(){
	ArrayList<Item> alInventory = new ArrayList();
        //Diamond operator is not supported in -source 1.6
        // ArrayList<Item> al = new ArrayList<>();  
        Item i0 = new Item("12",  "Circular saw", 150,  45.00, 125.00);
        Item i1 = new Item("235", "Cooking range", 50, 450.00, 850.00);
        Item i2 = new Item("301", "Table saw",    100, 125.00, 300.00);
        Item i3 = new Item("302", "Stapler",      300,  18.00,  49.00);
        Item i4 = new Item("303", "Lawn tractor",   5, 300.00, 650.00);           
	alInventory.add(i0);
        alInventory.add(i1);
        alInventory.add(i2);
        alInventory.add(i3);
        alInventory.add(i4);
        return alInventory; // return the ArrayList object alInventory
    }

    // Methods itemCheckDialogue, sellAnItem invoke method itemCheck
    // this method instantiates an object of iterator
    /**
     *
     * @param alPassed
     * @param itemIdPassed
     */
    public static Item itemCheck(
        ArrayList<Item> alPassed, String itemIdPassed){
        Iterator it = alPassed.iterator();
        while(it.hasNext())
        {
            Item temp = (Item)it.next();    //Cast
            String s = temp.getStrItemID();

            if( s.equals(itemIdPassed) ){
                return temp; // return the object 
            }
        }
        return null;         // not found
    }

    public static void checkToQuit(String s) {
        if(s.equals("999")){
            System.out.println("\nThank you for using this program.\n");
            System.exit(0);
        }
    }

    public static void displayMenu(){
        System.out.printf("\n\n** Welcome to the Java Hardware Store **\n");
        System.out.printf("\n1. Check whether an item is in the store");
        System.out.printf("\n2. Sell an item");
        System.out.printf("\n3. Print the report");
        System.out.printf("\n4. Exit\n\n");
    }

    public static void itemCheckDialogue(ArrayList<Item> alPassed){
        Item item = null;
        Scanner input = new Scanner(System.in);
        while(item == null){
            System.out.printf("\nPlease enter the ItemId "
                        + "(or 999 to quit):\n");
            String s = input.next();
            checkToQuit(s);
            String itemKb = s;
            item = itemCheck(alPassed, itemKb); // item or null
            if(item == null){
                System.out.printf("The ItemId %s was not found.\n", itemKb);
            }
            else{
                String itemName = item.getStrItemName();
                int qoh = item.getIntPiecesInStore();
                System.out.printf(
                        "%s [%s] has an in-store inventory of %d.\n", 
                        itemKb, itemName, qoh);
            }
        }
    }

    public static void sellAnItem(ArrayList<Item> alPassed){
        Item item = null;
        Scanner input = new Scanner(System.in);

        int customerID = readCustomerFile();
        itemReport(alPassed);
        
        while(item == null){
            System.out.printf("\nPlease enter the ItemId "
                        + "(or 999 to quit): ");
            String s = input.next();
            checkToQuit(s);
            String itemKb = s;
            item = itemCheck(alPassed, itemKb);
            // item obj or null is returned
            if(item == null){
                System.out.printf("The ItemId %s was not found.\n", itemKb);
            }
            else{
                int qoh = item.getIntPiecesInStore(); 
                String itemName = item.getStrItemName();
                System.out.printf(
                        "%s [%s] has an in-store inventory of %d.  ", 
                        itemKb, itemName, qoh);
                System.out.printf("How many do you want? ");
                s = input.next();
                int units = Integer.parseInt(s);
                double subTotal = 0;
                int orderType = 0;
                if(units > qoh){
                    System.out.printf(
                            "\nSorry, there is insufficient inventory"
                          + " to fill your order.");
                }else{
                    System.out.println();
                    //Call method to Order
                    orderProcessing(findCustomerId(customerID), 
                                    item, 
                                    units, 
                                    qoh);
                } // > else
            } // not null else
        } // not while loop
    } // sellAnItem

    /**
     *
     */
    protected static int totalInventory = 0;
    
    public static void itemReport(ArrayList<Item> alPassed){

        double totalDollars = 0.0;
        System.out.print("\nStore Inventory - - - - - - - - - - - ");
        System.out.println("- - - - - - - - - - - - - - - ");
        System.out.printf("ItemId   Item Name        Pieces in Store"
                        + "  ManufPrice  SellingPrice");
        for(Item item : alPassed){
            totalInventory += item.getIntPiecesInStore();
            totalDollars += item.getIntPiecesInStore()
                          * item.getDblSellingPrice();
            String itemId = item.getStrItemID();
            String itemName = item.getStrItemName();
            int pInStore = item.getIntPiecesInStore();
            double manufPrice = item.getDblManufPrice();
            double sellingPrice = item.getDblSellingPrice();
            System.out.printf("\n%4s   %-20s   %5d          %6.2f"
                       + "        %6.2f", itemId, itemName, pInStore, 
                       manufPrice, sellingPrice ); 
                            // note “%-20s” to left-justify Name
        } // for each item
            //totalDollars (formatted with DecimalFormat formNumber)
            String totalDollarsStr = String.format("%8s",
                                     formNumber.format(totalDollars));
            
            //Instead of using printf totalDollars
            //Use DecimalFormat formNumber totalDollarsStr
            System.out.printf(
                       "\n\n  Total Inventory: %s", totalDollarsStr);
            System.out.printf(
                       "   Total number of items in the store: %d\n", 
                       totalInventory);
    } // itemReport

}