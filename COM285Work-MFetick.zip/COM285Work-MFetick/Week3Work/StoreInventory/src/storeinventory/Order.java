/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 9)Add the java class Order to store information about the customer's order
 * @author Michael Fetick, 84270
 */
import java.util.*;
import java.text.DecimalFormat;

public class Order extends Customer implements CashCustomer, CreditCustomer {

    private Node next;
    private int idNumber;
    private String name;
    private double creditLimit;
    //Class variable formNumber for all the methods
    static DecimalFormat formNumber = new DecimalFormat("$#,###,###.00");

    public static void orderProcessing (Node customer, 
                                        Item item, 
                                        int qtyOrdered, 
                                        int qoh) {
        double sellingPrice = item.getDblSellingPrice();
        String sellingPriceStr = String.format("%8s",
                                           formNumber.format(sellingPrice));
        double subTotal = qtyOrdered * sellingPrice;
        String subTotalStr = String.format("%8s",
                                           formNumber.format(subTotal));
        String plusShipHandStr = String.format("%8s",
                                           formNumber.format(subTotal+4));
        Scanner input = new Scanner(System.in);
        //Prompt for orderType, in store or online
        int orderType = 0;
        while(orderType == 0){
            System.out.println("\n"
                             + "Store Order - - - - - - - - - - - - - - ");
            String strItemName = item.getStrItemName();
            System.out.printf(" (%d)%s X %s = %s\n", 
                              qtyOrdered, 
                              strItemName, 
                              sellingPriceStr, 
                              subTotalStr);
            System.out.println("Enter: 1 for in-store order "
                    + "(save shipping & handling charge)");
            System.out.println("       2 for online-order "
                    + "(add $4.00 shipping & handling charge)\n");
            String s = input.next();
            if(s.equals("1")){
                orderType = 1;
            }else if(s.equals("2")){
                orderType = 2;
                subTotal = subTotal + 4;
                System.out.println(
                       "Add $4.00 S&H charge for subtotal: " 
                     + plusShipHandStr);
            }
        }
        //Call method to findCustomerId(n) and getCreditLimit
        int creditType = 0;
        double creditLimit = customer.getCreditLimit();
        String creditLimitStr = String.format(
                "%8s",formNumber.format(creditLimit));
        double cashTotal = subTotal * CASH_DISCOUNT;
        String cashTotalStr = String.format("%8s",
                                            formNumber.format(cashTotal));
        double cashDiscount = subTotal * (1-CASH_DISCOUNT);
        String cashDiscountStr = String.format("%8s",
                                            formNumber.format(cashDiscount));
        double creditTotal = subTotal * CREDIT_SURCHARGE;
        String creditTotalStr = String.format("%8s",
                                            formNumber.format(creditTotal));
        double creditSurcharge = subTotal * (CREDIT_SURCHARGE - 1);
        String creditSurchargeStr = String.format("%8s",
                                            formNumber.format(creditSurcharge));
        System.out.println("\nCustomer Selected - - - - - - - - - - -"); 
        System.out.println("  ID  Name                 Credit Limit"); 
        System.out.printf("%4d  %-20s %7.2f\n", 
                          customer.getIdNumber(), 
                          customer.getName(),
                          customer.getCreditLimit());
        System.out.println("\n"
                         + "Payment type  - - - - - - - - - - - - - ");
        if(creditLimit == 0){
            creditType = -2;
            System.out.println(
                           "No credit on account, cash only payment.");
        }else{
            creditType = 2;
            if(creditTotal > creditLimit) {
                System.out.println(
                        "Insufficient credit for purchase: " + creditTotalStr); 
                System.out.println(
                        "Cash only payment: " + cashTotalStr);
            }else{
                //Prompt for payType, cash or credit
                int payType = 0;
                double total = 0;
                String totalStr;
                String strItemName = item.getStrItemName();
                while(payType == 0){
                    System.out.print("Enter: 1 to pay by cash ");
                    System.out.println("(minus 2% discount:  -"
                          + cashDiscountStr + ")");
                    System.out.print("       2 to pay by credit ");
                    System.out.println("(add 2% surcharge: +"
                          + creditSurchargeStr + ")");
                    String s = input.next();
                    int newqoh = qoh - qtyOrdered;
                    if(s.equals("1")){
                        item.setIntPiecesInStore(newqoh);
                        payType = 1;
                        System.out.println("\nYour order is accepted.\n"); 
                        System.out.printf(" (%d)%s X %s = %s\n", 
                                          qtyOrdered, 
                                          strItemName, 
                                          sellingPriceStr, 
                                          subTotalStr);
                        if(orderType == 2){
                            System.out.println(
                                    "  Add shipping & handling:       $4.00");
                        }
                        if(payType == 1){
                            System.out.println(
                                       "  Minus 2% cash discount: - " 
                                     + cashDiscountStr);
                        }else if(payType == 2){
                            System.out.println(
                                       "  Add 2% credit surcharge:  + " 
                                     + creditSurchargeStr);
                        }
                        total = cashTotal;
                        totalStr = String.format("%8s",
                                                 formNumber.format(total));
                        System.out.printf("                       "
                                        + "Total: %s. Thank you.", totalStr);
                        System.out.printf(
                                "The total is %s. Thank you.", totalStr);
                    }else if(s.equals("2")){
                        item.setIntPiecesInStore(newqoh);
                        payType = 2;
                        System.out.println("\nYour order is accepted,"
                                + " confirmation number: 201306170101\n"); 
                        System.out.printf(" (%d)%s X %s = %s\n", 
                                          qtyOrdered, 
                                          strItemName, 
                                          sellingPriceStr, 
                                          subTotalStr);
                        if(orderType == 2){
                            System.out.println(
                                    "  Add shipping & handling:       $4.00");
                        }
                        if(payType == 1){
                            System.out.println(
                                       "  Minus 2% cash discount: - " 
                                     + cashDiscountStr);
                        }else if(payType == 2){
                            System.out.println(
                                       "  Add 2% credit surcharge:  + " 
                                     + creditSurchargeStr);
                        }
                        total = creditTotal;
                        totalStr = String.format("%8s",
                                                 formNumber.format(total));
                        System.out.printf("  You will be charged, "
                                        + "Total: %s. Thank you.", totalStr);
                    }//end else if
                System.out.print("\n\nPress 1 to continue...");
                s = input.next();
                }//end While:payType = 0
            }//end else: Prompt for payType, cash or credit
        }//end else: Call method to getCreditLimit
    }
}