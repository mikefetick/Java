/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * 10a)CashCustomer extended from object Customer
 * @author Michael Fetick, 84270
 */
//public class CashCustomer extends Customer {
public interface CashCustomer {

    /**
     * Method getTotalPrice returns totalPrice with a 2% cash discount
     * @param quantitySold
     * @param sellingPrice
     */
    final static double CASH_DISCOUNT = .98; //2% CASH DISCOUNT
}