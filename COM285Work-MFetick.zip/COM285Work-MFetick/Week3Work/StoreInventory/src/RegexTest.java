/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 84270
 */
import java.util.regex.*;

public class RegexTest {
    
    public static void main(String args[])
    {
        String pattern = "[a-z]+";
        String text = "Now is the time";

        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        while (m.find())
            System.out.println( text.substring(m.start(), m.end() ) );
    }
}