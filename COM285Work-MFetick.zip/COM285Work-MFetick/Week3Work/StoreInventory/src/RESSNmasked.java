/* COM285, Michael Fetick, 84270
 * Exercise - Java Regular Expressions
 * 06/19/2013
 */
import java.util.regex.*;

/**
 *
 * @author 84270
 */
public class RESSNmasked {
	public static void main(String[] args) {
		String input = "User clientId=23421. "
                        + "Some more text clientId=33432. "
                        + "This clientNum=100";

		Pattern p = Pattern.compile("(clientId=)(\\d+)");
		Matcher m = p.matcher(input);

		StringBuffer result = new StringBuffer();
		while (m.find()) {
	        System.out.println("Masking: " + m.group(2));
		   m.appendReplacement(result, m.group(1) + "***masked***");
		}
		m.appendTail(result);
		System.out.println(result);
	}
}
/*
run:
 Masking: 23421
 Masking: 33432
 User clientId=***masked***. 
 Some more text clientId=***masked***. 
 This clientNum=100
BUILD SUCCESSFUL (total time: 0 seconds)
*/