/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 2)This interface defines the dog
 * @author Michael Fetick, 84270
 */
public abstract class Dog implements Animal {
    private String name;

    public Dog(String n) {
        name = n;
    }
    /**
     *Override speak()
     * @return "Woof Woof"
     */
    @Override
    public String speak() {
        return "Woof Woof";
    }
    public boolean iscarnivore() {
        super.getClass();
        return true;
    }

    @Override
    public boolean isCarnivore() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}