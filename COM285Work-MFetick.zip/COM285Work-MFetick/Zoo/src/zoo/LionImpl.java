/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package zoo;


public class LionImpl extends Lion {

    @Override
    public boolean isCarnivore() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public LionImpl(String n) {
        super(n);
    }
}
