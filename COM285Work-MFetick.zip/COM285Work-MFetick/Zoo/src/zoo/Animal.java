/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 2)This interface defines the animal
 * @author Michael Fetick, 84270
 */
public interface Animal {
    public String speak();
    public boolean isCarnivore();
}