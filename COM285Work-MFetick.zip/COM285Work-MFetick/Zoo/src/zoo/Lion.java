/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 2)This interface defines the lion
 * @author Michael Fetick, 84270
 */
public abstract class Lion implements Animal {
    private String name;

    public Lion(String n) {
        name = n;
    }
    /**
     *Override speak()
     * @return "Roaaaaaar"
     */
    @Override
    public String speak() {
        return "Roaaaaaar";
    }
    public boolean iscarnivore() {
        return true;
    }
}