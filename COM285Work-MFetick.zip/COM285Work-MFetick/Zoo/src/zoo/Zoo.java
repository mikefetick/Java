/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */
public class Zoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Enclosure<Dog> dogCages[] = (Enclosure<Dog>[])new Object[3];
        Dog[] myDogs = new Dog[3];
        myDogs[0] = new Dog("Buster") {};
        myDogs[1] = new Dog("Spencer") {};
        myDogs[2] = new Dog("Roxy") {};
        Enclosure.fill(myDogs, dogCages);
        
        Enclosure<Cat> catCages[] = (Enclosure<Cat>[])new Object[2];
        Cat[] myCats = new Cat[3];
        myCats[0] = new Cat("Garfield") {};
        myCats[1] = new Cat("Tom") {};
        myCats[2] = new Cat("Kitty") {};
        Enclosure.fill(myCats, catCages);
        
        Enclosure<Lion> lionCages[] = (Enclosure<Lion>[])new Object[1];
        Lion[] myLions = new Lion[3];
        myLions[0] = new Lion("Leo") {

            @Override
            public boolean isCarnivore() {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
        myLions[1] = new Lion("Simba") {

            @Override
            public boolean isCarnivore() {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
        myLions[2] = new Lion("Bastard") {

            @Override
            public boolean isCarnivore() {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
        Enclosure.fill(myLions, lionCages);
    }
}
