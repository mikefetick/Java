/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 3)This class defines the enclosure for the animal
 * @author Michael Fetick, 84270
 */
//Using a bounded type parameter to implement the Animal interface
public class Enclosure<T extends Animal> {

    private static void println(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private T occupant;
    
    public void addOccupant(T o){
            occupant = o;
    }
    public T getOccupant(){
            return occupant;
    }
    public T removeOccupant(){
            T retVal = occupant;
            occupant = null;
            return retVal;
    }
    /**
     *Method fill to put an animal in a cage
     * @param <U>
     * @param pets
     * @param cages
     */
    public static <U extends Animal> void fill(U[] pets, Enclosure<U>[] cages){
            for (int i = 0; i < pets.length; i++) {
                cages[i] = new zoo.Enclosure<T>(pets[i]);
            }
//    public static <U extends Animal> void fill(U[] pets, Enclosure<U>[] cages){
//            for (int i = 0; i < pets.length; i++) {
//                cages[i] = new Enclosure<U>(pets[i]);
//            }
    }
    /**
     *Method lists animals in the cages
     * @param <U>
     * @param pets
     * @param cages
     */
    public static <U extends Animal> void lists(U[] pets, Enclosure<U>[] cages){
            for (int i = 0; i < pets.length; i++) {
                System.out.print("Cage:" + cages[i]);
                System.out.println(",  Pet:" + Enclosure<U>(pets[i]);
            }
//    public static <U extends Animal> void fill(U[] pets, Enclosure<U>[] cages){
//            for (int i = 0; i < pets.length; i++) {
//                cages[i] = new Enclosure<U>(pets[i]);
//            }
    }
}
