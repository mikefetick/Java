/* COM285, Michael Fetick, 84270
 * Exercise: Using Generics, textbook, pages 154-164
 */
package zoo;

/**
 * 2)This interface defines the cat
 * @author Michael Fetick, 84270
 */
public abstract class Cat implements Animal {
    private String name;

    public Cat(String n) {
        name = n;
    }
    /**
     *Override speak()
     * @return "Meow Meow"
     */
    @Override
    public String speak() {
        return "Meow Meow";
    }
    public boolean iscarnivore() {
        return false;
    }

    @Override
    public boolean isCarnivore() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}