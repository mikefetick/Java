/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Exercise 2 - Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Exercise 5 - Read a file to an ArrayList and Sort it(2 points)
 *              This class has the Main() method
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import static storeinventory.Inventory.checkToQuit;

/**
 * 9)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy/Rename files: SinglyLinkedList, Operations, and Node
 *   b)This class uses LinkedListOps to readCustomerFile
 *   c)Correct the package name
 *   d)Correct the main method to be method readCustomerFile
 * @author Michael Fetick, 84270
 */
public class DataFileOperations extends LinkedListOps {
    /**
     * @param args the command line arguments
     */
    private static LinkedListOps opns = new LinkedListOps();    
    private static String errorMsg;    

    public static LinkedListOps readCustomerFile() {
        // While scanner hasNext, set string to next node
        FileReader customerDataFile = null;
        BufferedReader customerData = null;
        try { 
            //For Project 3 GUI datafile: customer.csv
            //Instantiate (Open) stream objects
            customerDataFile = new FileReader("Customer.csv");
            customerData = new BufferedReader(customerDataFile);
        } catch (FileNotFoundException fnfe) {
            System.err.println("Customer datafile:  " + fnfe.getMessage());
            System.exit(1);
            //Progammer's note: 
            // The above System.err.println... displays:
            // Customer datafile:  Customer.csv ...
            // (The system cannot find the file specified)
            //Which is better than using the following code:
            // errorMsg = "Error: opening customerDataFile.";
            // System.out.println(errorMsg);
        }
        Scanner scanner = new Scanner(customerData);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter("[,\n]");  // Comma Separated Value csv file
        while (scanner.hasNext()) { // while has next recond
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            String addr = scanner.next();
            String custType = scanner.next();

            //For Project 3 datafile: customer.csv
            Customer newNode = new Customer(idNumber, name, addr, custType);
            //For Project 2 datafile: customer2.csv            
            //  double creditLimit = scanner.nextDouble();
            //  Customer newNode = new Customer(idNumber, name, creditLimit);
            newNode.setNext(null);  //Good practice to avoid a stray pointer
            opns.insertInOrder(newNode);
            System.out.println();
        }
        try {
            //Close stream objects
            if (customerData != null){
                customerData.close();
            }
        } catch (IOException ioe) {
            System.err.println("Customer datafile:  " + ioe.getMessage());
            System.exit(1);
        }
        return opns;
    }
        
    public static int listCustomers(LinkedListOps opns) {
        
        opns.list();

        Scanner input = new Scanner(System.in);
        int customerID = 0;
        while (customerID == 0) {
            System.out.println("\nPlease enter the Customer's idNumber "
                    + "(or 999 to quit):");
            String s = input.next();
            checkToQuit(s);
            customerID = Integer.parseInt(s); 
        }
        System.out.println();
        return customerID;
    }

    public static ArrayList readProductFile() throws NoSuchElementException {
        
        FileReader productDataFile = null;
        BufferedReader productData = null;
        try { 
            //For Project 3 GUI datafile: customer.csv
            //Instantiate (Open) stream objects
            productDataFile = new FileReader("Product.csv");
            productData = new BufferedReader(productDataFile);
        } catch (FileNotFoundException fnfe) {
            System.err.println("Product datafile:  " + fnfe.getMessage());
            System.exit(1);
        }
        Scanner scanner = new Scanner(productData);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter("[,\n]");  // Comma Separated Value csv file
	ArrayList<Item> alProducts = new ArrayList();
        int i = 0;
        while (scanner.hasNext()) { // while has next recond
            // Changed from int to String
            String productId = scanner.next();
            String productName = scanner.next();
            String productPrice = scanner.next();
            double dblProductPrice = Double.parseDouble(productPrice); 
            Item thisItem1 = new Item(productId,
                                     productName,
                                     dblProductPrice);
            alProducts.add(thisItem1);
        }
        try {
            //Close stream objects
            if (productData != null){
                productData.close();
            }
        } catch (IOException ioe) {
            System.err.println("Product datafile:  " + ioe.getMessage());
            System.exit(1);
        }
        return alProducts;
    }
    
    public static ArrayList readInventoryFile() throws NoSuchElementException {
        
        FileReader inventoryDataFile = null;
        BufferedReader inventoryData = null;
        try { 
            //For Project 3 GUI datafile: customer.csv
            //Instantiate (Open) stream objects
            inventoryDataFile = new FileReader("Inventory.csv");
            inventoryData = new BufferedReader(inventoryDataFile);
        } catch (FileNotFoundException fnfe) {
            System.err.println("Inventory datafile:  " + fnfe.getMessage());
            System.exit(1);
        }
        Scanner scanner = new Scanner(inventoryData);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter("[,\n]");  // Comma Separated Value csv file
	ArrayList<Item> alInventory = new ArrayList();
        int i = 0;
        while (scanner.hasNext()) { // while has next recond
            String productId = scanner.next();
            String qtyOnHand = scanner.next();
            qtyOnHand = qtyOnHand.trim();
            int intQtyOnHand = Integer.parseInt(qtyOnHand); 
            Item thisItem2 = new Item(productId,
                                     intQtyOnHand);
            alInventory.add(thisItem2);
        }
        try {
            //Close stream objects
            if (inventoryData != null){
                inventoryData.close();
            }
        } catch (IOException ioe) {
            System.err.println("Inventory datafile:  " + ioe.getMessage());
            System.exit(1);
        }
        return alInventory;
    }
}
