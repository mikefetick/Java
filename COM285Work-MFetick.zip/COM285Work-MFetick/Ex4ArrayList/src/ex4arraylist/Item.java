/* COM285, Michael Fetick, 84270
 * Exercise 4: Read a file to an ArrayList (2 Points)
 * Step 1. Create this project Ex4ArrayList and this header comment
 */
package ex4arraylist;

/**
 * 2)Add the java class Item to store the information about the items
 * @author Michael Fetick, 84270
 */
public class Item { // 2)Class declaration

    // State of an Item. 3)Declare instance variables
    private int intProductID;       //The item ID
    private String strName;     //The item name
    private double dblPrice; //The selling price

    // 4)Use NetBeans to generate Constructors
    public Item() { 
        this.intProductID = 0;
        this.strName = "";
        this.dblPrice = 0.0;
    }

    public Item(int intProductID, 
                String strName, 
                double dblPrice) {
        this.intProductID = intProductID;
        this.strName = strName;
        this.dblPrice = dblPrice;
    }

    // Behavior of an Item. 5)Use NetBeans to generate getters and setters
    public int getIntProductID() {  
        return intProductID;
    }

    public void setIntProductID(int intProductID) {
        this.intProductID = intProductID;
    }

    public String getStrName() {
        return strName;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public double getDblPrice() {
        return dblPrice;
    }

    public void setPrice(double dblPrice) {
        this.dblPrice = dblPrice;
    }

    // 6) Override the toString() method
    @Override
    public String toString() {
        return super.toString(); 
    }
}
