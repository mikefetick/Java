/* COM285, Michael Fetick, 84270
 * Exercise 4: Read a file to an ArrayList (2 Points)
 * Step 1. Create this project Ex4ArrayList and this header comment
 */
package ex4arraylist;

import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Step 2. Comment on this class. 
 * It has the main method and performs steps 3 through 10.
 * @author Michael Fetick, 84270
 */
public class Ex4ArrayList {

    /**
     * Step 3. Comment on this main method.
     * It opens and reads file: "product.csv" 
     * @param args the command line arguments
     */

    // Step 7. Create class Item to build an ArrayList<Item> alProducts
    // Step 11. Make ArrayList a class variable with private
    private static ArrayList<Item> alProducts = new ArrayList();

    public static void main(String[] args) {
        // Step 4. Import java.io.FileReader and declare an object
        FileReader dataFile = null;

        // Step 5. Make a try-catch block for FileNotFoundException
        try {
            dataFile = new FileReader("product.csv");
        } catch (FileNotFoundException ex) {
            System.out.println("Something is wrong with the data file.");
            System.exit(0);
        }
        // Step 6. Import java.util.* and declare an object
        Scanner scanner = new Scanner(dataFile);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter(",|\\n");  // Comma Separated Value csv file

        // Step 8. While file has data, read each element 
        while (scanner.hasNext()) { // while - not end of file
            int idNumber = scanner.nextInt();
            String name = scanner.next();
            double price = scanner.nextDouble();

            // Step 9. Iteratively, assign values to the ArrayList
            Item product = new Item(idNumber, name, price);
            alProducts.add(product);
//            System.out.println(product);
            scanner.nextLine();
        }
        // Step 12. Call method DisplayProducts to display the ArrayList
        DisplayProducts();
        System.exit(0);
    }

    // Step 10. Create method DisplayProducts to display the ArrayList
    private static void DisplayProducts() {
        System.out.println("\nList of Products - - - - - - - - - - - ");
        for(Item item : alProducts){
            // Step 11. Iteratively, assign local variables from elements
            int productId = item.getIntProductID();
            String productName = item.getStrName();
            double productPrice = item.getDblPrice();
            // Step 11. Iteratively, display the local variables
            System.out.println(productId +" "
                             + productName +" "
                             + productPrice); 
        } // for each item
    }
}
